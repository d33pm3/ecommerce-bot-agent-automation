// Offline single-file build entry: same routes and same client-side logic as the
// hosted console, but running as a hash-history SPA with no server at all.
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { createRouter, createHashHistory, RouterProvider } from "@tanstack/react-router";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import { routeTree } from "../src/routeTree.gen";
import "./styles.css";

// The hosted app renders a full <html> document shell during SSR. There is no
// SSR here, so drop the shell and let the root component mount into #root.
const rootOptions = (routeTree as unknown as { options: Record<string, unknown> }).options;
delete rootOptions["shellComponent"];
delete rootOptions["head"];

const queryClient = new QueryClient();

const router = createRouter({
  routeTree,
  context: { queryClient },
  history: createHashHistory(),
  scrollRestoration: true,
  defaultPreloadStaleTime: 0,
});

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </StrictMode>,
);
