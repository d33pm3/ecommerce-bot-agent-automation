import { fileURLToPath } from "node:url";

import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig, type Plugin } from "vite";

const projectRoot = fileURLToPath(new URL("..", import.meta.url));

/** Fold every emitted JS/CSS asset into index.html so the demo is one file. */
function inlineEverything(): Plugin {
  return {
    name: "glx-inline-everything",
    enforce: "post",
    generateBundle(_options, bundle) {
      const html = Object.values(bundle).find(
        (f) => f.type === "asset" && f.fileName.endsWith(".html"),
      );
      if (!html || html.type !== "asset") return;
      let source = String(html.source);

      for (const file of Object.values(bundle)) {
        if (file.type === "asset" && file.fileName.endsWith(".css")) {
          const css = String(file.source);
          const link = new RegExp(
            `<link[^>]+href="[^"]*${file.fileName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}"[^>]*>`,
          );
          const tag = `<style>${css}</style>`;
          source = link.test(source) ? source.replace(link, () => tag) : source.replace("</head>", () => `${tag}</head>`);
          delete bundle[file.fileName];
        }
      }

      for (const file of Object.values(bundle)) {
        if (file.type === "chunk" && file.fileName.endsWith(".js")) {
          const script = new RegExp(
            `<script[^>]+src="[^"]*${file.fileName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}"[^>]*></script>`,
          );
          const tag = `<script type="module">${file.code.replace(/<\/script/gi, "<\\/script")}</script>`;
          source = script.test(source) ? source.replace(script, () => tag) : source.replace("</body>", () => `${tag}</body>`);
          delete bundle[file.fileName];
        }
      }

      html.source = source;
    },
  };
}

export default defineConfig({
  root: fileURLToPath(new URL(".", import.meta.url)),
  base: "./",
  plugins: [react(), tailwindcss(), inlineEverything()],
  resolve: {
    alias: { "@": fileURLToPath(new URL("./src", new URL("..", import.meta.url))) },
    dedupe: ["react", "react-dom", "@tanstack/react-router", "@tanstack/react-query"],
  },
  define: { "process.env.NODE_ENV": '"production"' },
  build: {
    outDir: fileURLToPath(new URL("../standalone-dist", import.meta.url)),
    emptyOutDir: true,
    cssCodeSplit: false,
    chunkSizeWarningLimit: 20_000,
    modulePreload: { polyfill: false },
    rollupOptions: { output: { inlineDynamicImports: true } },
  },
  server: { fs: { allow: [projectRoot] } },
});
